import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class UI extends JFrame implements MouseListener,ActionListener

{
	private JPanel panel;
	private JLabel label;
	private JButton yes, no;
	private JFrame jf;	
	
	
	public UI()
	{
		super("Fool Game");
		this.setSize(850,600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//this.setBackground(Color.white);
		
		
		
		panel= new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.white);
		
		
		label = new JLabel("Are you a fool?");
		label.setBounds(300,100,200,50);
		label.setFont(new Font("Calibri",Font.BOLD+Font.ITALIC,30));
		panel.add(label);
		
		yes = new JButton("yes");
		yes.setBounds(250,175,80,35);
		yes.setBackground(Color.blue);
		yes.addMouseListener(this);
		yes.addActionListener(this);
		panel.add(yes);
		

		no = new JButton("NO");
		no.setBounds(350,175,80,25);
		no.setBackground(Color.blue);
		no.addMouseListener(this);
		no.addActionListener(this);
		panel.add(no);
		
		
		this.add(panel);
	}
	
	
	Random r = new Random();
	
	
	public void mouseEntered(MouseEvent me)
	{
		if (me.getSource().equals(yes))
		{
			yes.setBackground(Color.WHITE);
		}
		else if(me.getSource().equals(no))
		{
			no.setBounds(r.nextInt(700),r.nextInt(400),80,25);
		}
		else{}
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource().equals(yes))
		{
			yes.setBackground(Color.WHITE);
		}
		else{}
	}
	public void mouseReleased(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseClicked(MouseEvent me){}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource().equals(yes))
		{
			
			SecondUI a = new SecondUI("Yes, you are a fool!!");
			a.setVisible(true);
			this.setVisible(false);   
		}
		else if(ae.getSource().equals(no))
		{
			
			SecondUI a = new SecondUI("Congrats!'\n' you aren't a fool!!");
			a.setVisible(true);
			this.setVisible(false);   
		}
		
	}
	
}