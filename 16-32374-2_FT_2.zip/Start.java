public class Start
{
	public static void main(String []args)
	{
		UI userInterface = new UI();
		userInterface.setVisible(true);
	}
}