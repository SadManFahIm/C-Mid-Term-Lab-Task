import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class SecondUI extends JFrame implements MouseListener,ActionListener
{
	private JPanel panel;
	private JLabel label,label2;
	private JButton yes,no;
	
	
	public SecondUI(String s)
	{
		super("Retry");
		this.setSize(800,450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel= new JPanel();
		panel.setLayout(null);
		
		
		label = new JLabel(s);
		label.setBounds(200,100,450,50);
		label.setFont(new Font("Calibri",Font.BOLD+Font.ITALIC,30));
		panel.add(label);
		
		label2 = new JLabel("Do you want to play again?");
		label2.setBounds(200,200,350,50);
		label2.setFont(new Font("Calibri",Font.BOLD+Font.ITALIC,30));
		panel.add(label2);
		
		yes = new JButton("yes");
		yes.setBounds(250,250,80,25);
		yes.setBackground(Color.blue);
		yes.addMouseListener(this);
		yes.addActionListener(this);
		panel.add(yes);
		

		no = new JButton("no");
		no.setBounds(350,250,80,25);
		no.setBackground(Color.blue);
		no.addMouseListener(this);
		no.addActionListener(this);
		panel.add(no);
		
		
		this.add(panel);
	}
	
	
	
	
	
	public void mouseEntered(MouseEvent me)
	{
		if(me.getSource().equals(yes))
		{
			yes.setBackground(Color.PINK);
		}
		else if(me.getSource().equals(no))
		{
			no.setBackground(Color.PINK);
		}
		else{}
	}
	public void mouseExited(MouseEvent me)
	{
		if(me.getSource().equals(yes))
		{
			yes.setBackground(Color.black);
		}
		else if(me.getSource().equals(no))
		{
			no.setBackground(Color.green);
		}
		else{}
	}
	public void mouseReleased(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseClicked(MouseEvent me){}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource().equals(yes))
		{
			
			UI an= new UI();
			an.setVisible(true);
			this.setVisible(false);   
		}
		else if(ae.getSource().equals(no))
		{
			System.exit(0);
			   
		}
	}	
	
	
}